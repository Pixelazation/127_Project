import React from 'react';

import Rectangle5Image from 'src/assets/images/homepage_Rectangle_5.png';

import EllipseImage from 'src/assets/images/homepage_Ellipse.png';

import LifesaversPaperWokImage from 'src/assets/images/homepage_Lifesavers_Paper_Wok.png';

import Ellipse1Image from 'src/assets/images/homepage_Ellipse.png';

import Image1Image from 'src/assets/images/homepage_image_1.png';

import Rectangle7Image from 'src/assets/images/homepage_Rectangle_7.png';

import Rectangle8Image from 'src/assets/images/homepage_Rectangle_8.png';

import Rectangle6Image from 'src/assets/images/homepage_Rectangle_6.png';

import Photo621766538281941Image from 'src/assets/images/homepage_photo_6217665382819412830_m_removebg_preview_1.png';

import {
  styled
} from '@mui/material/styles';

const HomePage1 = styled("div")({
  backgroundColor: `rgba(230, 247, 255, 1)`,
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  width: `1363px`,
  height: `867px`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  overflow: `hidden`,
});

const Rectangle5 = styled("img")({
  height: `54px`,
  width: `1440px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const AddForms = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `286.02px`,
  height: `308px`,
  left: `319px`,
  top: `190px`,
});

const Rectangle1 = styled("div")({
  backgroundColor: `rgba(181, 218, 255, 1)`,
  borderRadius: `20px`,
  width: `286.02px`,
  height: `235.08px`,
  position: `absolute`,
  left: `0px`,
  top: `73px`,
});

const Ellipse = styled("img")({
  height: `122.65px`,
  width: `131.23px`,
  position: `absolute`,
  left: `72px`,
  top: `12px`,
});

const LifesaversPaperWok = styled("img")({
  height: `110.63px`,
  width: `158.4px`,
  objectFit: `contain`,
  position: `absolute`,
  left: `60px`,
  top: `20px`,
});

const BrowseRequest = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `286.02px`,
  height: `300px`,
  left: `796px`,
  top: `198px`,
});

const Rectangle11 = styled("div")({
  backgroundColor: `rgba(181, 218, 255, 1)`,
  borderRadius: `20px`,
  width: `286.02px`,
  height: `238.4px`,
  position: `absolute`,
  left: `0px`,
  top: `62px`,
});

const Ellipse1 = styled("img")({
  height: `122.2px`,
  width: `131.23px`,
  position: `absolute`,
  left: `70px`,
  top: `0px`,
});

const Image1 = styled("img")({
  height: `92.27px`,
  width: `98.64px`,
  objectFit: `cover`,
  position: `absolute`,
  left: `88px`,
  top: `15px`,
});

const BrowseButton = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `162.03px`,
  height: `65.48px`,
  left: `67px`,
  top: `199px`,
});

const Rectangle3 = styled("div")({
  backgroundColor: `rgba(146, 193, 240, 1)`,
  border: `1px solid rgba(0, 0, 0, 1)`,
  boxSizing: `border-box`,
  borderRadius: `35px`,
  width: `162.03px`,
  height: `65.48px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const ViewSlips = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(0, 0, 0, 1)`,
  fontStyle: `normal`,
  fontFamily: `JejuMyeongjo`,
  fontWeight: `400`,
  fontSize: `20px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  width: `145px`,
  position: `absolute`,
  left: `12px`,
  top: `22px`,
});

const Rectangle9 = styled("div")({
  backgroundColor: `rgba(217, 217, 217, 1)`,
  width: `1px`,
  height: `2px`,
  position: `absolute`,
  left: `1254px`,
  top: `24px`,
});

const NavBar = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `58px`,
  height: `54px`,
  left: `1305px`,
  top: `0px`,
});

const Rectangle7 = styled("img")({
  height: `5.28px`,
  width: `39.16px`,
  position: `absolute`,
  left: `9px`,
  top: `38px`,
});

const Rectangle8 = styled("img")({
  height: `5.28px`,
  width: `39.16px`,
  position: `absolute`,
  left: `8px`,
  top: `24px`,
});

const Rectangle6 = styled("img")({
  height: `5.28px`,
  width: `39.16px`,
  position: `absolute`,
  left: `9px`,
  top: `9px`,
});

const Rectangle10 = styled("div")({
  backgroundColor: `rgba(217, 217, 217, 0)`,
  border: `1px solid rgba(128, 173, 219, 1)`,
  boxSizing: `border-box`,
  borderRadius: `5px`,
  width: `58px`,
  height: `54px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Photo621766538281941 = styled("img")({
  height: `49px`,
  width: `48px`,
  objectFit: `cover`,
  position: `absolute`,
  left: `22px`,
  top: `3px`,
});

const CareAndCureHub = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(0, 0, 0, 1)`,
  fontStyle: `normal`,
  fontFamily: `JejuMyeongjo`,
  fontWeight: `400`,
  fontSize: `36px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  width: `388px`,
  height: `62px`,
  position: `absolute`,
  left: `18px`,
  top: `-4px`,
});

const AddButton = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `162.04px`,
  height: `65.72px`,
  left: `382px`,
  top: `402px`,
});

const Rectangle31 = styled("div")({
  backgroundColor: `rgba(146, 193, 240, 1)`,
  border: `1px solid rgba(0, 0, 0, 1)`,
  boxSizing: `border-box`,
  borderRadius: `35px`,
  width: `162.04px`,
  height: `65.72px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const AddSlip = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(0, 0, 0, 1)`,
  fontStyle: `normal`,
  fontFamily: `JejuMyeongjo`,
  fontWeight: `400`,
  fontSize: `20px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  width: `146.11px`,
  height: `32.24px`,
  position: `absolute`,
  left: `8px`,
  top: `22px`,
});


function HomePage() {
  return (
    <HomePage1>
      <Rectangle5 src={Rectangle5Image} loading='lazy' alt={"Rectangle 5"}/>
      <AddForms>
        <Rectangle1>
        </Rectangle1>
        <Ellipse src={EllipseImage} loading='lazy' alt={"Ellipse"}/>
        <LifesaversPaperWok src={LifesaversPaperWokImage} loading='lazy' alt={"Lifesavers Paper Wok"}/>
      </AddForms>
      <BrowseRequest>
        <Rectangle11>
        </Rectangle11>
        <Ellipse1 src={Ellipse1Image} loading='lazy' alt={"Ellipse"}/>
        <Image1 src={Image1Image} loading='lazy' alt={"image 1"}/>
        <BrowseButton>
          <Rectangle3>
          </Rectangle3>
          <ViewSlips>
            {`VIEW SLIPS`}
          </ViewSlips>
        </BrowseButton>
      </BrowseRequest>
      <Rectangle9>
      </Rectangle9>
      <NavBar>
        <Rectangle7 src={Rectangle7Image} loading='lazy' alt={"Rectangle 7"}/>
        <Rectangle8 src={Rectangle8Image} loading='lazy' alt={"Rectangle 8"}/>
        <Rectangle6 src={Rectangle6Image} loading='lazy' alt={"Rectangle 6"}/>
        <Rectangle10>
        </Rectangle10>
      </NavBar>
      <Photo621766538281941 src={Photo621766538281941Image} loading='lazy' alt={"photo_6217665382819412830_m-removebg-preview 1"}/>
      <CareAndCureHub>
        {`Care and Cure Hub`}
      </CareAndCureHub>
      <AddButton>
        <Rectangle31>
        </Rectangle31>
        <AddSlip>
          {`ADD SLIP
`}
        </AddSlip>
      </AddButton>
    </HomePage1>);

  }

export default HomePage;

  