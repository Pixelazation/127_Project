export default function ViewSlips() {
  return (
    <div className="bg-[#E6F7FF] p-[17px_70.8px_0_70.8px] w-[1440px] box-sizing-border">
      <div className="bg-[#92C1F0] absolute left-[50%] top-[0px] translate-x-[-50%] w-[1440px] h-[67px]">
      </div>
      <span className="relative break-words font-['JejuMyeongjo'] font-normal text-[40px] text-[#000000]">
      CCH
      </span>
      <div className="bg-[url('assets/images/Photo6217665382819412830MremovebgPreview2.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[24px] top-[5px] w-[53.8px] h-[58px]">
      </div>
    </div>
  )
}