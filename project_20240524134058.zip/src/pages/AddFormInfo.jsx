export default function AddFormInfo() {
  return (
    <div className="bg-[#E6F7FF] p-[18px_60.8px_0_60.8px] w-[1374px] box-sizing-border">
      <div className="bg-[url('assets/images/Photo6217665382819412830MremovebgPreview2.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[12px] top-[9px] w-[53.8px] h-[58px]">
      </div>
      <div className="relative flex flex-col items-center w-[1070.2px] h-[fit-content] box-sizing-border">
        <div className="m-[0_0_9px_0] flex flex-row justify-between w-[1070.2px] box-sizing-border">
          <span className="relative m-[0_20px_0_0] w-[224.2px] break-words font-['JejuMyeongjo'] font-normal text-[40px] text-[#000000]">
          CCH
          </span>
          <div className="rounded-[3px] bg-[#92C1F0] m-[8px_0_3px_0] w-[826px] h-[29px]">
          </div>
        </div>
        <span className="m-[0_324.8px_0_0] break-words font-['Droid_Sans','Roboto_Condensed'] font-normal text-[24px] text-[#000000]">
        Personal Information
        </span>
      </div>
    </div>
  )
}